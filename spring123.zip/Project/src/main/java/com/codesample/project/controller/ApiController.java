package com.codesample.project.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.transaction.Transactional;

import org.apache.catalina.security.SecurityConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.codesample.project.data.Drinks;

import com.codesample.project.data.Menuadds;
import com.codesample.project.data.Product;
import com.codesample.project.data.Result;
import com.codesample.project.data.Admin;
import com.codesample.project.repository.AdminRepository;
import com.codesample.project.repository.DrinksRepository;

import com.codesample.project.repository.MenuaddsRepository;
import com.codesample.project.repository.ProductRepository;

@RestController
@RequestMapping("/api")
public class ApiController {

	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private DrinksRepository drinksRepository;
	@Autowired
	private MenuaddsRepository menuAddsRepository;
	@Autowired
	private AdminRepository adminRepository;
	@Autowired
	private PasswordEncoder passwordEncoder;

	@GetMapping("/order")
	public List<Drinks> getDrinks() {
		return drinksRepository.findAll();
	}

	public List<Product> getProduct() {
		return productRepository.findAll();
	}

	public List<Menuadds> getMenuadds() {
		return menuAddsRepository.findAll();
	}

	@GetMapping("/search")
	public List<Product> getProduct2() {
		return productRepository.findAll();
	}

	public List<Drinks> getDrinks2() {
		return drinksRepository.findAll();
	}

	public List<Menuadds> getMenuadds2() {
		return menuAddsRepository.findAll();
	}

	@Transactional
	@PostMapping("/adminadd")
	public Result addAdmin(@RequestBody HashMap<String, Object> map) {
		Admin ad = new Admin();
		ad.setROLE((String) map.get("option"));
		ad.setPassword(passwordEncoder.encode((String) map.get("pw")));
		ad.setName((String) map.get("name"));
		ad.setAdmin_Id((String) map.get("id"));
		adminRepository.save(ad);
		System.out.println(ad.getPassword());
		System.out.println(ad.getAdmin_Id());
		return new Result("ok");
	}
	
}
