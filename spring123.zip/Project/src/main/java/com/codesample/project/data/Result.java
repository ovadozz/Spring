package com.codesample.project.data;


public class Result {

	public String result;
	public Result() {}
	public Result(String result) {
		this.result = result;
	}
}
