package com.codesample.project.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.tools.DocumentationTool.Location;
import javax.transaction.Transactional;

import org.apache.catalina.security.SecurityConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.ws.transport.http.HttpUrlConnection;

import com.codesample.project.data.Drinks;

import com.codesample.project.data.Menuadds;
import com.codesample.project.data.Product;
import com.codesample.project.data.Result;
import com.codesample.project.data.Admin;
import com.codesample.project.repository.AdminRepository;
import com.codesample.project.repository.DrinksRepository;

import com.codesample.project.repository.MenuaddsRepository;
import com.codesample.project.repository.ProductRepository;
import com.codesample.project.service.AdminService;

@RestController
@RequestMapping("/api")
public class ApiController {

	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private DrinksRepository drinksRepository;
	@Autowired
	private MenuaddsRepository menuAddsRepository;
	@Autowired
	private AdminRepository adminRepository;
	@Autowired
	private PasswordEncoder passwordEncoder;
	@Autowired
	private AdminService adminService;

	@GetMapping("/order")
	public List<Drinks> getDrinks() {
		return drinksRepository.findAll();
	}

	public List<Product> getProduct() {
		return productRepository.findAll();
	}

	public List<Menuadds> getMenuadds() {
		return menuAddsRepository.findAll();
	}

	@GetMapping("/search")
	public List<Product> getProduct2() {
		return productRepository.findAll();
	}

	public List<Drinks> getDrinks2() {
		return drinksRepository.findAll();
	}

	public List<Menuadds> getMenuadds2() {
		return menuAddsRepository.findAll();
	}

	@Transactional
	@PostMapping("/adminadd")
	public Result addAdmin(@RequestBody HashMap<String, Object> map) {
		Admin ad = new Admin();
		ad.setROLE((String) map.get("option"));
		ad.setPassword(passwordEncoder.encode((String) map.get("pw")));
		ad.setName((String) map.get("name"));
		ad.setAdmin_Id((String) map.get("id"));
		adminRepository.save(ad);
		System.out.println(ad.getPassword());
		System.out.println(ad.getAdmin_Id());
		return new Result("ok");
	}

	@PostMapping("/adminLogin")
	public Result adminLogin(@RequestBody HashMap<String, Object> map) {
		// System.out.println(adminRepository.findById2().toString());
		List<Admin> search = adminRepository.findById2((String) map.get("id"));
//		System.out.println(search.get(0).getPassword());
//		System.out.println(passwordEncoder.encode((String) map.get("pw")));

		if (map.get("id").equals(search.get(0).getAdmin_Id())) {
			if (passwordEncoder.matches((String) map.get("pw"), search.get(0).getPassword())) {
				return new Result("ok");
			} else {
				return new Result("fail");
			}
		}
		return new Result("check");
	}

	@PostMapping("/regRamen")
	public Result regRamen(@RequestBody HashMap<String, Object> map) {
		Product product = new Product();
		int a = Integer.parseInt((String) map.get("inven"));
		int b = Integer.parseInt((String) map.get("cost"));
		product.setProdname((String) map.get("prodname"));
		product.setProductId((String) map.get("prodid"));
		product.setInventory(a);
		product.setCost(b);
		productRepository.save(product);
		return new Result("ok");
	}

	@PostMapping("/regDrink")
	public Result regDring(@RequestBody HashMap<String, Object> map) {
		Drinks drinks = new Drinks();
		int dcost = Integer.parseInt((String) map.get("dcost"));
		int dinven = Integer.parseInt((String) map.get("dinven"));
		drinks.setCost(dcost);
		drinks.setInventory(dinven);
		drinks.setDrinkname((String) map.get("drinkname"));
		drinks.setDrinkId((String) map.get("drinkid"));
		drinksRepository.save(drinks);
		return new Result("ok");
	}

	@PostMapping("/regAdd")
	public Result regAdd(@RequestBody HashMap<String, Object> map) {
		Menuadds adds = new Menuadds();
		int acost = Integer.parseInt((String) map.get("acost"));
		int ainven = Integer.parseInt((String) map.get("ainven"));
		adds.setCost(acost);
		adds.setInventory(ainven);
		adds.setAddsname((String) map.get("addname"));
		adds.setMenuaddid((String) map.get("addid"));
		menuAddsRepository.save(adds);
		return new Result("ok");
	}

	@DeleteMapping("/delprod")
	public Result delProd(@RequestBody HashMap<String, Object> map) {
		Product p = new Product();
		int a = Integer.parseInt((String) map.get("num"));
		p.setCatenum(a);
		productRepository.delete(p);
		return new Result("ok");
	}
	
	@DeleteMapping("/deldrink")
	public Result delDrink(@RequestBody HashMap<String, Object> map) {
		Drinks d = new Drinks();
		int a = Integer.parseInt((String) map.get("num"));
		d.setCatenum(a);
		drinksRepository.delete(d);
		return new Result("ok");
	}
	
	@DeleteMapping("/deladds")
	public Result delAdds(@RequestBody HashMap<String, Object> map) {
		Menuadds ad = new Menuadds();
		int a = Integer.parseInt((String) map.get("num"));
		ad.setCatenum(a);
		menuAddsRepository.delete(ad);
		return new Result("ok");
	}
	
	

	@PutMapping("/fixcost")
	public Result updateCost(@RequestBody HashMap<String, Object> map) {
		Product p = new Product();
		int cost = Integer.parseInt((String)map.get("cost"));
		System.out.println(map.get("num"));
		int num = Integer.parseInt((String)map.get("num"));
		
		Optional<Product> pn = adminService.findProdname(num);
		System.out.println(pn);
		pn.get().setCost(cost);
		adminService.apc(pn.get());
		return new Result("ok");
	}
	
	@PutMapping("/dfixcost")
	public Result updateDcost(@RequestBody HashMap<String, Object> map) {
		Drinks d = new Drinks();
		int cost = Integer.parseInt((String)map.get("cost"));
		System.out.println(map.get("num"));
		int num = Integer.parseInt((String)map.get("num"));
		
		Optional<Drinks> dc = adminService.findCatenum(num);
		System.out.println(dc);
		dc.get().setCost(cost);
		adminService.dpc(dc.get());
		return new Result("ok");
	}
	
	@PutMapping("/afixcost")
	public Result updateAcost(@RequestBody HashMap<String, Object> map) {
		Menuadds a = new Menuadds();
		int cost = Integer.parseInt((String)map.get("cost"));
		System.out.println(map.get("num"));
		int num = Integer.parseInt((String)map.get("num"));
		
		Optional<Menuadds> dc = adminService.findCatenum2(num);
		System.out.println(dc);
		dc.get().setCost(cost);
		adminService.dpc(dc.get());
		return new Result("ok");
	}
}
