package com.codesample.project.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.codesample.project.data.Admin;
import com.codesample.project.repository.AdminRepository;
import com.codesample.project.repository.DrinksRepository;
import com.codesample.project.repository.MenuaddsRepository;
import com.codesample.project.repository.ProductRepository;

@Controller
public class WebController {
	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private DrinksRepository drinksRepository;
	@Autowired
	private MenuaddsRepository menuAddsRepository;
	@Autowired
	private AdminRepository adminRepository;

		
	@GetMapping("/index")
	public String index() {
		return "index";
	}
	
	@GetMapping("/order")
	public String order(Model model) {
		model.addAttribute("order",productRepository.findAll());
		model.addAttribute("drinks",drinksRepository.findAll());
		model.addAttribute("adds",menuAddsRepository.findAll());
		return "order";
	}
	
	@GetMapping("/adminMain")
	public String adminMain() {
		return "adminMain";
	}
	@GetMapping("/search")
	public String search(Model model) {
		model.addAttribute("order",productRepository.findAll());
		model.addAttribute("drinks",drinksRepository.findAll());
		model.addAttribute("adds",menuAddsRepository.findAll());
		return "search";
	}
	@GetMapping("/regist")
	public String regist() {
		return "regist";
	}
	@GetMapping("/fix")
	public String fix(Model model) {
		model.addAttribute("order",productRepository.findAll());
		model.addAttribute("drink",drinksRepository.findAll());
		model.addAttribute("adds",menuAddsRepository.findAll());
		return "fix";
	}
	@GetMapping("/analyze")
	public String analyze() {
		return "analyze";
	}
	
	@GetMapping("/sysadmin")
	public String sysdamin() {
		return "sysadmin";
	}

	
	@GetMapping("/adminLogin")
	public String adminLogin() {
		return "adminLogin";
	}

}
