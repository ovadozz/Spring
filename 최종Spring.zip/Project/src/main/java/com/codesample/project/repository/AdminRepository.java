package com.codesample.project.repository;

import java.util.List;
import java.util.Optional;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.codesample.project.data.Admin;

@Repository
public interface AdminRepository  extends JpaRepository<Admin, String>{
	
	@Query(value = "SELECT s FROM Admin s WHERE s.admin_Id = :id",nativeQuery =false)
	public List<Admin> findById2(@Param (value = "id") String id);
}
