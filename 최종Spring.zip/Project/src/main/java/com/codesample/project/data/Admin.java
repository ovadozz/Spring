package com.codesample.project.data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="admins")
public class Admin {

	@Id 
    @GeneratedValue(strategy = GenerationType.IDENTITY)
		private int No;
		@Column(nullable = false, length = 50)
		private String admin_Id;
		@Column(nullable = false, length = 50)
		private String name;
		@Column(nullable = false, length = 100)
		private String password;
		private String ROLE;
		
		
		public Admin() {}
		
		public Admin(int No,String admin_Id, String name, String password,String ROLE) {
			this.No = No;
			this.admin_Id = admin_Id;
			this.name = name;
			this.password = password;
			this.ROLE = ROLE;
		}
		

		public String getROLE() {
			return ROLE;
		}

		public void setROLE(String rOLE) {
			ROLE = rOLE;
		}

		public int getNo() {
			return No;
		}

		public void setNo(int no) {
			No = no;
		}

		public String getAdmin_Id() {
			return admin_Id;
		}

		public void setAdmin_Id(String admin_Id) {
			this.admin_Id = admin_Id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		
}
