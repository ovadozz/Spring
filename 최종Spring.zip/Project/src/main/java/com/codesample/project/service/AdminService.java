package com.codesample.project.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codesample.project.data.Drinks;
import com.codesample.project.data.Menuadds;
import com.codesample.project.data.Product;
import com.codesample.project.repository.AdminRepository;
import com.codesample.project.repository.DrinksRepository;
import com.codesample.project.repository.MenuaddsRepository;
import com.codesample.project.repository.ProductRepository;

@Service
public class AdminService {
	
	@Autowired
	private AdminRepository adminRepository;
	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private DrinksRepository drinksRepository;
	@Autowired
	private MenuaddsRepository menuAddsRepository;
	
	
	
	public Optional<Product> findProdname(int catenum){
		Optional<Product> pn = productRepository.findById(catenum);
		return pn;
	}
	public void apc(Product product) {
		productRepository.save(product);
	}
	
	public Optional<Drinks> findCatenum(int catenum){
		Optional<Drinks> dc = drinksRepository.findById(catenum);
		return dc;
	}
	public void dpc (Drinks drinks) {
		drinksRepository.save(drinks);
	}
	
	public Optional<Menuadds> findCatenum2(int catenum){
		Optional<Menuadds> ac = menuAddsRepository.findById(catenum);
		return ac;
	}
	public void dpc (Menuadds menuadds) {
		menuAddsRepository.save(menuadds);
	}
}
